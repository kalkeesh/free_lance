from fastapi import FastAPI, File, UploadFile, Form, HTTPException
import os
from pathlib import Path
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import json



app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ASSETS_DIR = Path("assets")


ASSETS_DIR.mkdir(parents=True, exist_ok=True)

@app.post("/upload-image/")
async def upload_image(category: str = Form(...), description: str = Form(...), file: UploadFile = File(...)):
    category_path = ASSETS_DIR / category
    category_path.mkdir(parents=True, exist_ok=True)
    
    
    file_location = category_path / file.filename
    with open(file_location, "wb") as buffer:
        buffer.write(await file.read())

    
    description_file = category_path / f"{file.filename}.txt"
    with open(description_file, "w") as desc_file:
        desc_file.write(description)

    return {"info": f"File '{file.filename}' successfully uploaded to '{category}/'"}


@app.get("/images/")
async def list_images(category: str):
    category_path = ASSETS_DIR / category
    if not category_path.exists() or not category_path.is_dir():
        raise HTTPException(status_code=404, detail="Category not found")

    image_data = []
    
    
    for file in category_path.iterdir():
        if file.is_file() and not file.name.endswith(".txt"):
            description_file = category_path / f"{file.name}.txt"
            if description_file.exists():
                with open(description_file, "r") as desc_file:
                    description = desc_file.read().strip()
            else:
                description = "No description available"
            image_data.append({"name": file.name, "description": description})

    if not image_data:
        return {"message": f"No images found in '{category}' category"}
    
    return {"images": image_data}


@app.get("/images/{category}/{image_name}")
async def get_image(category: str, image_name: str):
    image_path = ASSETS_DIR / category / image_name
    if not image_path.exists() or not image_path.is_file():
        raise HTTPException(status_code=404, detail="Image not found")
    return FileResponse(image_path)

@app.post("/upload-news/")
async def upload_news(title: str = Form(...), paragraph: str = Form(...)):
    news_path = ASSETS_DIR / "news"
    news_path.mkdir(parents=True, exist_ok=True)
    news_file = news_path / f"{title}.txt"
    with open(news_file, "w") as file:
        file.write(f"Title: {title}\n\nParagraph:\n{paragraph}")
    return {"info": f"News article '{title}' successfully saved."}

@app.post("/upload-event/")
async def upload_event(event_name: str = Form(...), description: str = Form(...)):
    events_path = ASSETS_DIR / "events"
    events_path.mkdir(parents=True, exist_ok=True)
    event_file = events_path / f"{event_name}.txt"
    with open(event_file, "w") as file:
        file.write(f"Event Name: {event_name}\n\nDescription:\n{description}")
    return {"info": f"Event '{event_name}' successfully saved."}

@app.get("/get-news/")
async def get_news():
    news_path = ASSETS_DIR / "news"
    news_items = []
    
    if news_path.exists():
        for news_file in os.listdir(news_path):
            with open(news_path / news_file, "r") as file:
                content = file.read()
                title, paragraph = content.split('\n\nParagraph:\n', 1)
                news_items.append({
                    "title": title.replace("Title: ", ""),
                    "paragraph": paragraph
                })
    
    return {"news": news_items}
@app.get("/get-events/")
async def get_events():
    events_path = ASSETS_DIR / "events"
    event_items = []
    
    if events_path.exists():
        for event_file in os.listdir(events_path):
            with open(events_path / event_file, "r") as file:
                content = file.read()
                event_name, description = content.split('\n\nDescription:\n', 1)
                event_items.append({
                    "event_name": event_name.replace("Event Name: ", ""),
                    "description": description
                })
    
    return {"events": event_items}

