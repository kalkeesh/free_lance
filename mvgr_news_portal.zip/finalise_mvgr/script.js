// script1.js

// Function to open the login modal
function openLoginModal() {
    const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
    loginModal.show();
}

function login(event) {
    event.preventDefault();
    // Add your login logic here
    alert("Logged in!");
}

// Function to close all modals
function closeModals() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        const bootstrapModal = bootstrap.Modal.getInstance(modal);
        if (bootstrapModal) {
            bootstrapModal.hide();
        }
    });
}

// Close modals when clicking outside the modal content
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target == modal) {
            modal.style.display = 'none';
            modal.setAttribute('aria-hidden', 'true');
        }
    });
}

// Login function
function login(event) {
    event.preventDefault();
    const password = document.getElementById('adminPassword').value;
    // Replace 'yourpassword' with your actual admin password
    if (password === 'admin123') {
        closeModals(); // Assuming this closes the login modal correctly
        // Use Bootstrap's modal to show the admin panel
        const adminPanelModal = new bootstrap.Modal(document.getElementById('adminPanel'));
        adminPanelModal.show(); // Show the admin panel modal
    } else {
        alert('Incorrect password. Please try again.');
    }
}


// Logout function
function logout() {
    closeModals();
    alert('You have been logged out.');
}

// Function to show change password modal
function showChangePasswordModal() {
    closeModals();
    document.getElementById('changePasswordModal').style.display = 'block';
    document.getElementById('changePasswordModal').setAttribute('aria-hidden', 'false');
}

// Change password function
function changePassword(event) {
    event.preventDefault();
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmNewPassword = document.getElementById('confirmNewPassword').value;
    
    // Replace 'yourpassword' with your actual current password
    if (currentPassword !== 'yourpassword') {
        alert('Current password is incorrect.');
        return;
    }

    if (newPassword !== confirmNewPassword) {
        alert('New passwords do not match.');
        return;
    }

    // Implement password update logic here (e.g., send to server)
    alert('Password changed successfully.');
    closeModals();
}

// Function to upload image
// Function to upload image
async function uploadImage(event) {
    event.preventDefault();

    const image = document.getElementById('imageUpload').files[0];  // Get the selected image
    const description = document.getElementById('imageDescription').value;  // Get the description
    const category = document.getElementById('imageCategory').value;  // Get the category

    if (!image || !category || !description) {
        alert("Please select an image, category, and provide a description.");
        return;
    }

    const formData = new FormData();
    formData.append("file", image);  
    formData.append("category", category);
    formData.append("description", description);  // Include description in the form data

    try {
        const response = await fetch('http://127.0.0.1:8000/upload-image/', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const result = await response.json();
            alert(result.info);  // Show success message from the server
            document.getElementById('uploadForm').reset();  // Reset the form after successful upload
            closeModals();  // Close the modal after upload
        } else {
            alert("Failed to upload image. Please try again.");
        }
    } catch (error) {
        console.error("Error uploading image:", error);
        alert("An error occurred while uploading the image.");
    }
}
// -----------------------------------------------------------------------
// Function to display image in the modal
function openModal(imageSrc, imageDescription) {
    const modal = document.getElementById('imageModal');
    const modalImage = document.getElementById('modalImage');
    const modalCaption = document.getElementById('modalCaption');

    modal.style.display = 'block';
    modalImage.src = imageSrc;
    modalCaption.textContent = imageDescription;
    modal.setAttribute("aria-hidden", "false");
}

// Function to close the modal
function closeModal() {
    const modal = document.getElementById('imageModal');
    modal.style.display = 'none';
    modal.setAttribute("aria-hidden", "true");
}

async function filterImages(category) {
    const imageContainer = document.getElementById('image-container');
    imageContainer.innerHTML = '';  // Clear the existing images

    try {
        const response = await fetch(`http://127.0.0.1:8000/images/?category=${category}`);
        
        if (!response.ok) {
            alert("Failed to load images for the selected category.");
            return;
        }

        const data = await response.json();

        if (data.images && data.images.length > 0) {
            data.images.forEach(imageData => {
                const imgElement = document.createElement('img');
                imgElement.src = `http://127.0.0.1:8000/images/${category}/${imageData.name}`;
                imgElement.alt = imageData.name;
                imgElement.classList.add('gallery-image');
                imgElement.onclick = () => openModal(imgElement.src, imageData.description || "No description available");

                const descriptionElement = document.createElement('p');
                descriptionElement.textContent = imageData.description || "No description available";

                const imageWrapper = document.createElement('div');
                imageWrapper.classList.add('image-wrapper');
                imageWrapper.appendChild(imgElement);
                imageWrapper.appendChild(descriptionElement);

                imageContainer.appendChild(imageWrapper);
            });
        } else {
            imageContainer.innerHTML = `<p>No images found in '${category}' category.</p>`;
        }

    } catch (error) {
        console.error("Error loading images:", error);
        alert("An error occurred while loading images.");
    }
}

// Add modal support for images in showAllImages as well
async function showAllImages() {
    const categories = ['sports', 'cultural', 'academic', 'clubs', 'announcements', 'others'];
    const imageContainer = document.getElementById('image-container');
    imageContainer.innerHTML = '';  

    try {
        for (const category of categories) {
            const response = await fetch(`http://127.0.0.1:8000/images/?category=${category}`);
            
            if (!response.ok) {
                console.error(`Failed to load images for category: ${category}`);
                continue; 
            }
            const data = await response.json();
            if (data.images && data.images.length > 0) {
                data.images.forEach(imageData => {
                    const imgElement = document.createElement('img');
                    imgElement.src = `http://127.0.0.1:8000/images/${category}/${imageData.name}`;
                    imgElement.alt = imageData.name;
                    imgElement.classList.add('gallery-image');
                    imgElement.onclick = () => openModal(imgElement.src, imageData.description || "No description available");

                    const descriptionElement = document.createElement('p');
                    descriptionElement.textContent = imageData.description || "No description available";

                    const imageWrapper = document.createElement('div');
                    imageWrapper.classList.add('image-wrapper');
                    imageWrapper.appendChild(imgElement);
                    imageWrapper.appendChild(descriptionElement);

                    imageContainer.appendChild(imageWrapper);
                });
            }
        }
    } catch (error) {
        console.error("Error loading images:", error);
        alert("An error occurred while loading all images.");
    }
}
// Function to open the map modal
function openMapModal() {
    const modal = document.getElementById('mapModal');
    modal.style.display = 'block';
    modal.setAttribute("aria-hidden", "false");
}

// Function to close the map modal
function closeMapModal() {
    const modal = document.getElementById('mapModal');
    modal.style.display = 'none';
    modal.setAttribute("aria-hidden", "true");
}


// --------------------------------------------------------------------------------
// Fetch and display news dynamically
async function fetchNews() {
    const newsContainer = document.querySelector('.news-container');
    newsContainer.innerHTML = ''; 

    try {
        const response = await fetch('http://127.0.0.1:8000/get-news/');
        if (!response.ok) {
            alert("Failed to fetch news.");
            return;
        }

        const data = await response.json();
        data.news.forEach(newsItem => {
            const article = document.createElement('article');
            const title = document.createElement('h3');
            const paragraph = document.createElement('p');

            title.textContent = newsItem.title;
            paragraph.textContent = newsItem.paragraph;

            article.appendChild(title);
            article.appendChild(paragraph);
            newsContainer.appendChild(article);
        });

    } catch (error) {
        console.error("Error fetching news:", error);
        alert("An error occurred while fetching news.");
    }
}

// Fetch and display events dynamically
async function fetchEvents() {
    const eventList = document.querySelector('.upcoming-events div'); // Updated to select the correct container
    eventList.innerHTML = ''; 

    try {
        const response = await fetch('http://127.0.0.1:8000/get-events/');
        if (!response.ok) {
            alert("Failed to fetch events.");
            return;
        }

        const data = await response.json();
        data.events.forEach(eventItem => {
            const listItem = document.createElement('div');
            listItem.classList.add('col-md-3', 'mb-4'); // Add margin for spacing

            // Construct the event item HTML
            listItem.innerHTML = `
                <div class="event-item">
                    <h4>${eventItem.event_name}:</h4>
                    
                    <p><i class="far fa-clock me-2"></i>${eventItem.description}</p>
                </div>
            `;

            // Append the new event item to the event list
            eventList.appendChild(listItem);
        });

    } catch (error) {
        console.error("Error fetching events:", error);
        alert("An error occurred while fetching events.");
    }
}


// Call these functions to load news and events on page load
window.onload = function() {
    fetchNews();
    fetchEvents();
};


// Upload News Function
async function uploadNews(event) {
    event.preventDefault();

    const title = document.getElementById('newsTitle').value;
    const paragraph = document.getElementById('newsParagraph').value;

    if (!title || !paragraph) {
        alert("Please provide both the title and the paragraph.");
        return;
    }

    const formData = new FormData();
    formData.append("title", title);
    formData.append("paragraph", paragraph);

    try {
        const response = await fetch('http://127.0.0.1:8000/upload-news/', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const result = await response.json();
            alert(result.info); 
            document.getElementById('newsForm').reset();
        } else {
            alert("Failed to upload news.");
        }
    } catch (error) {
        console.error("Error uploading news:", error);
        alert("An error occurred while uploading the news.");
    }
}

// Upload Event Function
async function uploadEvent(event) {
    event.preventDefault();

    const eventName = document.getElementById('eventName').value;
    const eventDescription = document.getElementById('eventDescription').value;

    if (!eventName || !eventDescription) {
        alert("Please provide both the event name and description.");
        return;
    }

    const formData = new FormData();
    formData.append("event_name", eventName);
    formData.append("description", eventDescription);

    try {
        const response = await fetch('http://127.0.0.1:8000/upload-event/', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const result = await response.json();
            alert(result.info); 
            document.getElementById('eventForm').reset();
        } else {
            alert("Failed to upload event.");
        }
    } catch (error) {
        console.error("Error uploading event:", error);
        alert("An error occurred while uploading the event.");
    }
}
// -------------------------------------------------------------------------------
// Animate numbers in About section
const counters = document.querySelectorAll('.stats-counter');
counters.forEach(counter => {
    const target = parseInt(counter.getAttribute('data-count'));
    let count = 0;
    const increment = target / 100;
    const updateCounter = () => {
        if (count < target) {
            count += increment;
            counter.textContent = Math.ceil(count) + (counter.textContent.includes('+') ? '+' : '');
            requestAnimationFrame(updateCounter);
        }
    };
    updateCounter();
});

// Smooth scroll for navigation
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Add scroll animations
const observerOptions = {
    threshold: 0.1
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate__animated', 'animate__fadeIn');
        }
    });
}, observerOptions);

document.querySelectorAll('section').forEach(section => {
    observer.observe(section);
});
// -------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
    fetchCombinedMarquee();
});

async function fetchCombinedMarquee() {
    const combinedMarquee = document.querySelector('.combined-content');
    combinedMarquee.innerHTML = ''; 

    try {
        const newsResponse = await fetch('http://127.0.0.1:8000/get-news/');
        if (!newsResponse.ok) {
            alert("Failed to fetch news for marquee.");
            return;
        }
        const newsData = await newsResponse.json();

        const eventsResponse = await fetch('http://127.0.0.1:8000/get-events/');
        if (!eventsResponse.ok) {
            alert("Failed to fetch events for marquee.");
            return;
        }
        const eventsData = await eventsResponse.json();

        newsData.news.forEach(newsItem => {
            const newsText = document.createElement('span');
            newsText.innerHTML = `<strong>News:</strong> ${newsItem.title} &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;`;
            combinedMarquee.appendChild(newsText);
        });

        eventsData.events.forEach(eventItem => {
            const eventText = document.createElement('span');
            eventText.innerHTML = `<strong>Event:</strong> ${eventItem.event_name}&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;`;
            combinedMarquee.appendChild(eventText);
        });

    } catch (error) {
        console.error("Error fetching combined marquee data:", error);
        alert("An error occurred while fetching data for marquee.");
    }
}